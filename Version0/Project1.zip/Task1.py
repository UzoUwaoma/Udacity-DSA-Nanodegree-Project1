""""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


"""
TASK 1:
How many different telephone numbers are there in the records?
Print a message:
"There are <count> different telephone numbers in the records."
"""


# Create helper function to scan phone record for uniqueness
def check_phone_records(record, sender, receiver):
    """
    Args:
        record (List): Contains all unique phone numbers from a given database.
        sender (String): Phone number sending a text or call.
        receiver (String): Phone number receiving a text or call.

    Returns:
        None.
    """

    if sender not in record:
        record.append(sender)

    if receiver not in record:
        record.append(receiver)


# Initialize list to store unique phone numbers from provided database
unique_numbers = []

# Loop through text records and extract unique phone numbers
for ii in range(len(texts)):
    sending_number = texts[ii][0]
    receiving_number = texts[ii][1]

    check_phone_records(unique_numbers, sending_number, receiving_number)

# Loop through call records and extract unique phone numbers
for ii in range(len(calls)):
    sending_number = calls[ii][0]
    receiving_number = calls[ii][1]

    check_phone_records(unique_numbers, sending_number, receiving_number)

# Print to the console, the number of unique phone numbers
print("There are {} different telephone numbers in the records.".format(len(unique_numbers)))
